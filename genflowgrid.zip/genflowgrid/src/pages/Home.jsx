import React from "react";
import ScrollProgress from "@/components/portfolio/ScrollProgress";
import Navbar from "@/components/portfolio/Navbar";
import HeroSection from "@/components/portfolio/HeroSection";
import ArchiveSection from "@/components/portfolio/ArchiveSection";
import ServicesSection from "@/components/portfolio/ServicesSection";
import ProcessSection from "@/components/portfolio/ProcessSection";
import PortalSection from "@/components/portfolio/PortalSection";
import Footer from "@/components/portfolio/Footer";

// TODO: replace these with your real image files.
// Drop the files into /public/assets/images using these exact names,
// or edit the paths below to match whatever names you use.
const heroImage = "/assets/images/hero-bg.png";

const projects = [
  {
    num: "01",
    name: "IronForge",
    type: "Full-Scale Identity — Gym",
    year: "2025",
    image: "/assets/images/ironforge-bg.png",
    liveShot: "/assets/images/ironforge-live.png",
    theme: "forge",
    headline: [
      { text: "STRENGTH.", block: true },
      { text: "IDENTITY.", block: true },
      { text: "FORGED.", block: true, accent: true },
    ],
    description:
      "A full-scale digital identity for a 24/7 strength gym — branding, membership system, and class scheduling built from the ground up.",
    stats: [
      { value: "24/7", label: "ACCESS BUILT" },
      { value: "12+", label: "CLASS TEMPLATES" },
      { value: "1", label: "IDENTITY SYSTEM" },
    ],
  },
  {
    num: "02",
    name: "Sakhumzi Kitchen",
    type: "Digital Presence — Restaurant",
    year: "2025",
    image: "/assets/images/sakhumzi-bg.png",
    liveShot: "/assets/images/sakhumzi-live.png",
    theme: "ember",
    headline: [
      { text: "Slow food,", block: true },
      { text: "honest", accent: true },
      { text: " design.", block: true },
    ],
    description:
      "A warm, editorial digital presence for a neighbourhood restaurant — menu showcase, reservation flow, and brand storytelling made from scratch.",
    stats: [
      { value: "∞", label: "MENU ITEMS" },
      { value: "1", label: "RESERVATION FLOW" },
      { value: "3", label: "PAGE TEMPLATES" },
    ],
  },
  {
    num: "03",
    name: "The Fade Room",
    type: "Brand Architecture — Barber",
    year: "2025",
    image: "/assets/images/faderoom-bg.png",
    liveShot: "/assets/images/faderoom-live.png",
    theme: "fade",
    headline: [
      { text: "Sharp brands.", block: true },
      { text: "Quiet", accent: true },
      { text: " craft.", block: true },
    ],
    description:
      "A barber lounge brand built around craft and ritual — booking system, service menu, and an identity that cuts through the noise.",
    stats: [
      { value: "1", label: "BOOKING SYSTEM" },
      { value: "6+", label: "SERVICE TIERS" },
      { value: "1", label: "SIGNATURE BRAND" },
    ],
  },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-void">
      <ScrollProgress />
      <Navbar />
      <HeroSection heroImage={heroImage} />
      <ArchiveSection projects={projects} />
      <ServicesSection />
      <ProcessSection />
      <PortalSection />
      <Footer />
    </div>
  );
}
