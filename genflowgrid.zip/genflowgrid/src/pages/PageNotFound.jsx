import { useLocation } from 'react-router-dom';

export default function PageNotFound() {
    const location = useLocation();
    const pageName = location.pathname.substring(1);

    return (
        <div className="min-h-screen flex items-center justify-center p-6 bg-void">
            <div className="max-w-md w-full">
                <div className="text-center space-y-6">
                    <div className="space-y-2">
                        <h1 className="text-7xl font-heading font-bold text-bismuth/40">404</h1>
                        <div className="h-0.5 w-16 bg-white/10 mx-auto"></div>
                    </div>
                    <div className="space-y-3">
                        <h2 className="text-2xl font-heading font-bold text-lithos">
                            Page Not Found
                        </h2>
                        <p className="text-bismuth leading-relaxed">
                            The page <span className="font-medium text-lithos">"{pageName}"</span> could not be found.
                        </p>
                    </div>
                    <div className="pt-6">
                        <a
                            href="/"
                            className="inline-flex items-center px-6 py-3 font-mono text-xs tracking-[0.15em] uppercase text-void bg-kinetic hover:opacity-85 transition-opacity duration-300"
                        >
                            Go Home
                        </a>
                    </div>
                </div>
            </div>
        </div>
    )
}
