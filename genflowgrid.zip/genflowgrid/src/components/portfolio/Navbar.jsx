import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

const navItems = [
  { label: "ARCHIVE", href: "#archive" },
  { label: "SERVICES", href: "#services" },
  { label: "PROCESS", href: "#process" },
  { label: "PORTAL", href: "#portal" },
];

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-40 flex items-center justify-between px-6 md:px-10 py-5 transition-all duration-500 ${
          scrolled ? "bg-void/90 backdrop-blur-xl border-b border-white/[0.04]" : "bg-transparent"
        }`}
      >
        <a href="#home" className="font-mono text-xs tracking-[0.12em] text-lithos uppercase">
          GenFlowGrid<span className="text-kinetic">.</span>
        </a>

        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="relative w-8 h-8 flex flex-col items-end justify-center gap-1.5 group"
          aria-label="Toggle menu"
        >
          <span className={`block h-[1px] bg-lithos transition-all duration-500 ${menuOpen ? "w-6 rotate-45 translate-y-[3.5px]" : "w-8 group-hover:w-6"}`} />
          <span className={`block h-[1px] bg-lithos transition-all duration-500 ${menuOpen ? "w-6 -rotate-45 -translate-y-[3.5px]" : "w-5 group-hover:w-8"}`} />
        </button>
      </nav>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="fixed inset-0 z-30 bg-void/95 backdrop-blur-2xl flex items-end justify-end p-10 md:p-16"
          >
            <div className="flex flex-col items-end gap-4">
              {navItems.map((item, i) => (
                <motion.a
                  key={item.label}
                  href={item.href}
                  onClick={() => setMenuOpen(false)}
                  initial={{ opacity: 0, x: 40 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 40 }}
                  transition={{ delay: i * 0.08, duration: 0.4 }}
                  className="font-heading text-4xl md:text-6xl font-bold text-lithos hover:text-kinetic transition-colors duration-300 tracking-tight"
                >
                  {item.label}
                </motion.a>
              ))}
              <div className="flex items-center gap-4 mt-8">
                <a
                  href="mailto:GenFlowGrid@gmail.com"
                  className="font-mono text-[10px] tracking-[0.15em] text-bismuth hover:text-kinetic transition-colors duration-300 uppercase"
                >
                  Email
                </a>
                <span className="text-bismuth/30">|</span>
                <a
                  href="https://instagram.com/genflowgrid"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-mono text-[10px] tracking-[0.15em] text-bismuth hover:text-kinetic transition-colors duration-300 uppercase"
                >
                  Instagram
                </a>
              </div>
              <motion.span
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="font-mono text-[10px] tracking-[0.15em] text-bismuth/60 mt-4 uppercase"
              >
                Pretoria, South Africa
              </motion.span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
