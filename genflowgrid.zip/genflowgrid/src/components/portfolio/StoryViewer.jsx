import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronLeft, ChevronRight } from "lucide-react";

const STORY_DURATION = 5000;

export default function StoryViewer({ projects, startIndex, onClose }) {
  const [currentIndex, setCurrentIndex] = useState(startIndex || 0);
  const [progress, setProgress] = useState(0);
  const [paused, setPaused] = useState(false);

  const next = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1 >= projects.length ? 0 : prev + 1));
    setProgress(0);
  }, [projects.length]);

  const prev = useCallback(() => {
    setCurrentIndex((p) => (p - 1 < 0 ? projects.length - 1 : p - 1));
    setProgress(0);
  }, [projects.length]);

  useEffect(() => {
    if (paused) return;
    const startTime = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min((elapsed / STORY_DURATION) * 100, 100);
      setProgress(pct);
      if (pct >= 100) {
        clearInterval(interval);
        if (currentIndex >= projects.length - 1) {
          setTimeout(onClose, 300);
        } else {
          next();
        }
      }
    }, 16);
    return () => clearInterval(interval);
  }, [currentIndex, paused, projects.length, next, onClose]);

  const project = projects[currentIndex];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="fixed inset-0 z-[100] bg-void flex items-center justify-center"
      onMouseDown={() => setPaused(true)}
      onMouseUp={() => setPaused(false)}
      onTouchStart={() => setPaused(true)}
      onTouchEnd={() => setPaused(false)}
    >
      <div className="absolute top-0 left-0 right-0 z-50 flex items-center gap-1.5 px-4 pt-4">
        {projects.map((_, i) => (
          <div key={i} className="flex-1 h-[2px] bg-white/15 rounded-full overflow-hidden">
            <div
              className="h-full bg-lithos rounded-full transition-all duration-75 ease-linear"
              style={{ width: i < currentIndex ? "100%" : i === currentIndex ? `${progress}%` : "0%" }}
            />
          </div>
        ))}
      </div>

      <div className="absolute top-10 left-0 right-0 z-50 flex items-center justify-between px-5 pt-2">
        <div className="flex items-center gap-3">
          <span className="font-mono text-xs text-lithos tracking-wide">{project.num}</span>
          <span className="font-heading text-sm text-lithos font-bold tracking-tight">{project.name}</span>
          <span className="font-mono text-[10px] text-bismuth uppercase">{project.year}</span>
        </div>
        <button onClick={onClose} className="text-bismuth hover:text-kinetic transition-colors" aria-label="Close story">
          <X className="w-5 h-5" />
        </button>
      </div>

      <button
        onClick={prev}
        className="absolute left-0 top-0 bottom-0 w-1/3 z-40 cursor-pointer"
        aria-label="Previous"
      />
      <button
        onClick={next}
        className="absolute right-0 top-0 bottom-0 w-1/3 z-40 cursor-pointer"
        aria-label="Next"
      />

      <button onClick={prev} className="hidden md:flex absolute left-4 top-1/2 -translate-y-1/2 z-50 w-10 h-10 items-center justify-center text-bismuth hover:text-kinetic transition-colors" aria-label="Previous">
        <ChevronLeft className="w-6 h-6" />
      </button>
      <button onClick={next} className="hidden md:flex absolute right-4 top-1/2 -translate-y-1/2 z-50 w-10 h-10 items-center justify-center text-bismuth hover:text-kinetic transition-colors" aria-label="Next">
        <ChevronRight className="w-6 h-6" />
      </button>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, scale: 1.02 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 0.4 }}
          className="relative w-full h-full max-w-2xl mx-auto flex items-center justify-center"
        >
          <img
            src={project.image}
            alt={`${project.name} — ${project.type}`}
            className="w-full h-full object-contain"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-void via-transparent to-transparent pointer-events-none" />

          <div className="absolute bottom-0 left-0 right-0 p-8 md:p-12 z-30">
            <p className="font-mono text-[10px] tracking-[0.2em] text-kinetic uppercase mb-3">
              ● {project.type}
            </p>
            <h3 className="font-heading text-3xl md:text-5xl font-bold text-lithos tracking-tighter">
              {project.name}
            </h3>
            <div className="flex items-center gap-4 mt-6">
              <a
                href={project.url}
                target="_blank"
                rel="noopener noreferrer"
                className="font-mono text-[10px] tracking-[0.12em] text-kinetic uppercase hover:text-lithos transition-colors"
              >
                View Live ↗
              </a>
              <a
                href="#portal"
                onClick={onClose}
                className="font-mono text-[10px] tracking-[0.12em] text-bismuth hover:text-kinetic transition-colors uppercase"
              >
                Request Access & Specs
              </a>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {paused && (
        <div className="absolute bottom-8 right-8 z-50">
          <span className="font-mono text-[9px] tracking-[0.15em] text-kinetic uppercase">⏸ Paused</span>
        </div>
      )}
    </motion.div>
  );
}
