import React from "react";
import { motion } from "framer-motion";
import { Code, Palette, Package, Clapperboard, Smartphone, Layout } from "lucide-react";

const services = [
  {
    icon: Code,
    title: "Web Design & Development",
    desc: "Crafting responsive websites with seamless user experiences and e-commerce capabilities that drive business growth.",
  },
  {
    icon: Palette,
    title: "Logo Design & Branding",
    desc: "Developing strategic logos and brand identities that resonate with your audience and stand the test of time.",
  },
  {
    icon: Package,
    title: "Package Designing",
    desc: "Creating visually striking and functional packaging that enhances product appeal and strengthens brand presence.",
  },
  {
    icon: Clapperboard,
    title: "Animation",
    desc: "Bringing ideas to life through dynamic 3D animations and engaging video content that captivates and informs.",
  },
  {
    icon: Smartphone,
    title: "App Development",
    desc: "Building powerful and scalable mobile and web applications designed to deliver seamless performance and growth.",
  },
  {
    icon: Layout,
    title: "UI / UX",
    desc: "A strong UI/UX design should seamlessly blend aesthetics with functionality, ensuring an intuitive experience across all devices.",
  },
];

export default function ServicesSection() {
  return (
    <section id="services" className="py-24 md:py-40 px-6 md:px-10">
      <div className="flex items-start justify-between mb-16 md:mb-24">
        <div>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="font-mono text-[10px] tracking-[0.2em] text-kinetic uppercase mb-4"
          >
            ● Capabilities
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold text-lithos tracking-tighter leading-[0.95]"
          >
            WHAT WE
            <br />
            BUILD
          </motion.h2>
        </div>
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="hidden md:block font-mono text-[10px] tracking-[0.15em] text-bismuth uppercase text-right max-w-[200px]"
        >
          Full-spectrum digital craft — from identity to deployment
        </motion.p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {services.map((service, i) => {
          const Icon = service.icon;
          return (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ delay: i * 0.08, duration: 0.6 }}
              className="group p-8 md:p-10 border border-white/[0.04] bg-white/[0.01] hover:bg-white/[0.03] hover:border-kinetic/20 transition-all duration-500 flex flex-col"
            >
              <div className="flex items-center justify-between mb-10">
                <div className="w-12 h-12 rounded-full border border-kinetic/20 bg-kinetic/5 flex items-center justify-center group-hover:bg-kinetic group-hover:border-kinetic transition-all duration-500">
                  <Icon className="w-5 h-5 text-kinetic group-hover:text-void transition-colors duration-500" />
                </div>
                <span className="font-mono text-[10px] tracking-[0.2em] text-bismuth uppercase">
                  {String(i + 1).padStart(2, "0")}
                </span>
              </div>
              <h3 className="font-heading text-xl md:text-2xl font-bold text-lithos tracking-tight mb-4 group-hover:text-kinetic transition-colors duration-500">
                {service.title}
              </h3>
              <p className="text-sm text-bismuth leading-relaxed flex-1">
                {service.desc}
              </p>
              <div className="mt-8 flex items-center gap-2">
                <a
                  href="#portal"
                  className="font-mono text-[10px] tracking-[0.15em] text-kinetic uppercase hover:gap-3 transition-all duration-300 flex items-center gap-2"
                >
                  Inquire <span>→</span>
                </a>
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
