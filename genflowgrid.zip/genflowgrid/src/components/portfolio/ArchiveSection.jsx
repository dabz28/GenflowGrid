import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, ArrowRight } from "lucide-react";

const AUTO_ADVANCE_MS = 8000;

const THEMES = {
  forge: {
    accent: "#FF6B35",
    text: "#FFFFFF",
    textMuted: "rgba(255,255,255,0.55)",
    overlay: "linear-gradient(105deg, rgba(8,8,8,0.94) 0%, rgba(8,8,8,0.78) 40%, rgba(8,8,8,0.35) 100%)",
    bottomFade: "linear-gradient(to top, rgba(8,8,8,0.5), transparent 35%)",
    cardBorder: "rgba(255,107,53,0.2)",
    cardShadow: "0 0 80px rgba(255,107,53,0.1)",
    btnPrimaryBg: "#FF6B35",
    btnPrimaryText: "#0A0A0A",
    btnSecondaryBorder: "rgba(255,255,255,0.2)",
    btnSecondaryText: "#FFFFFF",
    progressFill: "#FF6B35",
    progressBg: "rgba(255,255,255,0.15)",
    eyebrowBg: "rgba(255,107,53,0.08)",
    eyebrowBorder: "rgba(255,107,53,0.3)",
    arrowBorder: "rgba(255,255,255,0.1)",
    arrowText: "rgba(255,255,255,0.5)",
    headlineClass: "uppercase",
    accentItalic: false,
    headlineSize: "text-5xl sm:text-6xl md:text-7xl lg:text-8xl",
    statsBorder: "rgba(255,255,255,0.1)",
  },
  fade: {
    accent: "#D9A65D",
    text: "#FFFFFF",
    textMuted: "rgba(255,255,255,0.5)",
    overlay: "linear-gradient(105deg, rgba(8,8,8,0.93) 0%, rgba(8,8,8,0.75) 40%, rgba(8,8,8,0.3) 100%)",
    bottomFade: "linear-gradient(to top, rgba(8,8,8,0.45), transparent 35%)",
    cardBorder: "rgba(217,166,93,0.2)",
    cardShadow: "0 0 80px rgba(217,166,93,0.1)",
    btnPrimaryBg: "#D9A65D",
    btnPrimaryText: "#0A0A0A",
    btnSecondaryBorder: "rgba(255,255,255,0.2)",
    btnSecondaryText: "#FFFFFF",
    progressFill: "#D9A65D",
    progressBg: "rgba(255,255,255,0.15)",
    eyebrowBg: "rgba(217,166,93,0.08)",
    eyebrowBorder: "rgba(217,166,93,0.3)",
    arrowBorder: "rgba(255,255,255,0.1)",
    arrowText: "rgba(255,255,255,0.5)",
    headlineClass: "",
    accentItalic: true,
    headlineSize: "text-4xl sm:text-5xl md:text-6xl lg:text-7xl",
    statsBorder: "rgba(255,255,255,0.1)",
  },
  ember: {
    accent: "#A66A4A",
    text: "#3D2821",
    textMuted: "rgba(61,40,33,0.55)",
    overlay: "linear-gradient(105deg, rgba(249,240,230,0.95) 0%, rgba(249,240,230,0.85) 40%, rgba(249,240,230,0.45) 100%)",
    bottomFade: "linear-gradient(to top, rgba(249,240,230,0.5), transparent 35%)",
    cardBorder: "rgba(61,40,33,0.1)",
    cardShadow: "0 24px 60px rgba(61,40,33,0.14)",
    btnPrimaryBg: "#3D2821",
    btnPrimaryText: "#F9F0E6",
    btnSecondaryBorder: "rgba(61,40,33,0.2)",
    btnSecondaryText: "#3D2821",
    progressFill: "#A66A4A",
    progressBg: "rgba(61,40,33,0.15)",
    eyebrowBg: "rgba(166,106,74,0.08)",
    eyebrowBorder: "rgba(166,106,74,0.3)",
    arrowBorder: "rgba(61,40,33,0.12)",
    arrowText: "rgba(61,40,33,0.5)",
    headlineClass: "",
    accentItalic: true,
    headlineSize: "text-4xl sm:text-5xl md:text-6xl lg:text-7xl",
    statsBorder: "rgba(61,40,33,0.1)",
  },
};

export default function ArchiveSection({ projects }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [paused, setPaused] = useState(false);

  const next = useCallback(() => {
    setCurrentIndex((p) => (p + 1 >= projects.length ? 0 : p + 1));
    setProgress(0);
  }, [projects.length]);

  const prev = useCallback(() => {
    setCurrentIndex((p) => (p - 1 < 0 ? projects.length - 1 : p - 1));
    setProgress(0);
  }, [projects.length]);

  useEffect(() => {
    if (paused) return;
    const startTime = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min((elapsed / AUTO_ADVANCE_MS) * 100, 100);
      setProgress(pct);
      if (pct >= 100) {
        clearInterval(interval);
        next();
      }
    }, 16);
    return () => clearInterval(interval);
  }, [currentIndex, paused, next]);

  const project = projects[currentIndex];
  const theme = THEMES[project.theme] || THEMES.forge;

  return (
    <section
      id="archive"
      className="relative min-h-screen overflow-hidden"
      onMouseDown={() => setPaused(true)}
      onMouseUp={() => setPaused(false)}
      onTouchStart={() => setPaused(true)}
      onTouchEnd={() => setPaused(false)}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={`bg-${currentIndex}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
          className="absolute inset-0"
        >
          <img
            src={project.image}
            alt={`${project.name} brand visual`}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: theme.overlay }} />
          <div className="absolute inset-0" style={{ background: theme.bottomFade }} />
          <div
            className="absolute inset-0 opacity-[0.015]"
            style={{
              backgroundImage: `linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)`,
              backgroundSize: "64px 64px",
            }}
          />
        </motion.div>
      </AnimatePresence>

      <div className="absolute top-0 left-0 right-0 z-40 flex items-center gap-1.5 px-6 md:px-10 pt-24 md:pt-28">
        {projects.map((_, i) => (
          <div key={i} className="flex-1 h-[2px] rounded-full overflow-hidden" style={{ background: theme.progressBg }}>
            <div
              className="h-full rounded-full transition-all duration-75 ease-linear"
              style={{
                width: i < currentIndex ? "100%" : i === currentIndex ? `${progress}%` : "0%",
                background: theme.progressFill,
              }}
            />
          </div>
        ))}
      </div>

      <button onClick={prev} className="absolute left-0 top-0 bottom-0 w-1/3 z-30 cursor-pointer" aria-label="Previous project" />
      <button onClick={next} className="absolute right-0 top-0 bottom-0 w-1/3 z-30 cursor-pointer" aria-label="Next project" />

      <button
        onClick={prev}
        className="hidden md:flex absolute left-4 top-1/2 -translate-y-1/2 z-40 w-12 h-12 items-center justify-center border transition-all duration-300"
        style={{ borderColor: theme.arrowBorder, color: theme.arrowText }}
        aria-label="Previous"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>
      <button
        onClick={next}
        className="hidden md:flex absolute right-4 top-1/2 -translate-y-1/2 z-40 w-12 h-12 items-center justify-center border transition-all duration-300"
        style={{ borderColor: theme.arrowBorder, color: theme.arrowText }}
        aria-label="Next"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      <div className="relative z-20 min-h-screen flex items-center px-6 md:px-10 pt-28 pb-16">
        <div className="w-full max-w-7xl mx-auto flex flex-col lg:flex-row items-center lg:items-center gap-10 lg:gap-16">
          <AnimatePresence mode="wait">
            <motion.div
              key={`text-${currentIndex}`}
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -40 }}
              transition={{ duration: 0.6 }}
              className="flex-1 max-w-2xl"
            >
              <div
                className="inline-flex items-center gap-2 px-4 py-2 mb-8 border"
                style={{ background: theme.eyebrowBg, borderColor: theme.eyebrowBorder }}
              >
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: theme.accent }} />
                <span
                  className="font-mono text-[10px] tracking-[0.2em] uppercase"
                  style={{ color: theme.accent }}
                >
                  {project.num} / {String(projects.length).padStart(2, "0")} — {project.type}
                </span>
              </div>

              <h2
                className={`font-heading font-bold tracking-tighter leading-[0.9] ${theme.headlineSize} ${theme.headlineClass}`}
                style={{ color: theme.text }}
              >
                {project.headline.map((part, i) => (
                  <span
                    key={i}
                    className={part.block ? "block" : "inline"}
                    style={{
                      color: part.accent ? theme.accent : "inherit",
                      fontStyle: part.accent && theme.accentItalic ? "italic" : "normal",
                      fontWeight: part.accent && theme.accentItalic ? 400 : "inherit",
                    }}
                  >
                    {part.text}
                  </span>
                ))}
              </h2>

              <p
                className="text-sm md:text-base leading-relaxed mt-6 max-w-lg"
                style={{ color: theme.textMuted }}
              >
                {project.description}
              </p>

              {project.stats && (
                <div
                  className="flex items-stretch gap-8 mt-8 pt-6 border-t"
                  style={{ borderColor: theme.statsBorder }}
                >
                  {project.stats.map((stat, i) => (
                    <div key={i}>
                      <p
                        className="font-heading text-2xl md:text-3xl font-bold tracking-tight"
                        style={{ color: theme.accent }}
                      >
                        {stat.value}
                      </p>
                      <p
                        className="font-mono text-[9px] tracking-[0.15em] uppercase mt-1"
                        style={{ color: theme.textMuted }}
                      >
                        {stat.label}
                      </p>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex flex-col sm:flex-row items-start gap-4 mt-10">
                <a
                  href="#portal"
                  className="inline-flex items-center gap-2 px-8 py-4 font-mono text-xs tracking-[0.15em] uppercase transition-all duration-500 hover:opacity-85"
                  style={{ background: theme.btnPrimaryBg, color: theme.btnPrimaryText }}
                >
                  Request Access & Specs
                  <ArrowRight className="w-4 h-4" />
                </a>
                <button
                  onClick={next}
                  className="inline-flex items-center gap-2 px-8 py-4 border font-mono text-xs tracking-[0.15em] uppercase transition-all duration-500 hover:gap-3"
                  style={{ borderColor: theme.btnSecondaryBorder, color: theme.btnSecondaryText }}
                >
                  Next Project
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          </AnimatePresence>

          <AnimatePresence mode="wait">
            <motion.div
              key={`shot-${currentIndex}`}
              initial={{ opacity: 0, scale: 0.96, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: -20 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="hidden lg:block w-[440px] flex-shrink-0"
            >
              <div
                className="overflow-hidden rounded-lg border backdrop-blur-sm"
                style={{ borderColor: theme.cardBorder, boxShadow: theme.cardShadow }}
              >
                <div className="flex items-center gap-1.5 px-4 py-3 border-b" style={{ borderColor: theme.cardBorder }}>
                  <span className="w-2.5 h-2.5 rounded-full" style={{ background: theme.accent, opacity: 0.5 }} />
                  <span className="w-2.5 h-2.5 rounded-full" style={{ background: theme.accent, opacity: 0.3 }} />
                  <span className="w-2.5 h-2.5 rounded-full" style={{ background: theme.accent, opacity: 0.15 }} />
                  <span
                    className="font-mono text-[9px] tracking-[0.15em] uppercase ml-3"
                    style={{ color: theme.textMuted }}
                  >
                    {project.name} — Live Preview
                  </span>
                </div>
                <img
                  src={project.liveShot}
                  alt={`${project.name} live website screenshot`}
                  className="w-full h-auto block"
                />
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30">
        <motion.p
          animate={{ opacity: [0.3, 0.8, 0.3] }}
          transition={{ duration: 2.5, repeat: Infinity }}
          className="font-mono text-[9px] tracking-[0.2em] uppercase text-center"
          style={{ color: theme.textMuted }}
        >
          ← Tap to browse →
        </motion.p>
      </div>

      {paused && (
        <div className="absolute bottom-6 right-6 z-40">
          <span
            className="font-mono text-[9px] tracking-[0.15em] uppercase"
            style={{ color: theme.accent }}
          >
            ⏸ Paused
          </span>
        </div>
      )}
    </section>
  );
}
