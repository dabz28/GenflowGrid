import React from "react";
import { motion } from "framer-motion";
import { Play } from "lucide-react";

export default function WorkCard({ project, index, isOversized, onOpenStory }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 60 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ delay: index * 0.1, duration: 0.7 }}
      className={`group relative overflow-hidden bg-white/[0.02] border border-white/[0.04] ${
        isOversized ? "md:col-span-2 md:row-span-2" : ""
      }`}
    >
      <div className="relative overflow-hidden aspect-[4/5] cursor-pointer" onClick={() => onOpenStory(index)}>
        <img
          src={project.image}
          alt={`${project.name} — ${project.type} project showcase`}
          className="w-full h-full object-cover transition-transform duration-[600ms] ease-out group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-void/30 group-hover:bg-void/10 transition-all duration-500" />

        <div className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full border border-kinetic/30 bg-void/60 backdrop-blur-sm flex items-center justify-center group-hover:bg-kinetic group-hover:border-kinetic transition-all duration-500">
          <Play className="w-3.5 h-3.5 text-kinetic group-hover:text-void transition-colors duration-500" fill="currentColor" />
        </div>

        <div className="absolute top-0 left-0 right-0 p-5 flex items-start justify-between">
          <span className="font-mono text-[10px] tracking-[0.15em] text-bismuth uppercase">
            {project.num}
          </span>
          <span className="font-mono text-[10px] tracking-[0.15em] text-bismuth uppercase mr-12">
            {project.year}
          </span>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-5">
          <p className="font-heading text-xl md:text-2xl font-bold text-lithos tracking-tight">
            {project.name}
          </p>
          <p className="font-mono text-[10px] tracking-[0.12em] text-bismuth uppercase mt-1">
            {project.type}
          </p>
        </div>
      </div>

      <div className="p-4 flex items-center justify-between border-t border-white/[0.04]">
        <a
          href={project.url}
          target="_blank"
          rel="noopener noreferrer"
          className="font-mono text-[10px] tracking-[0.12em] text-bismuth uppercase hover:text-lithos transition-colors duration-300 flex items-center gap-2"
        >
          View Live <span className="text-sm">↗</span>
        </a>
        <button
          onClick={() => onOpenStory(index)}
          className="px-4 py-2 bg-kinetic/10 text-kinetic font-mono text-[10px] tracking-[0.12em] uppercase hover:bg-kinetic hover:text-void transition-all duration-500"
        >
          ▶ View Story
        </button>
      </div>
    </motion.div>
  );
}
