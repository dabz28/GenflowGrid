import React from "react";

export default function Footer() {
  return (
    <footer className="px-6 md:px-10 py-8 border-t border-white/[0.04]">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <span className="font-mono text-[10px] tracking-[0.15em] text-bismuth uppercase">© 2026 GenFlowGrid

        </span>
        <div className="flex items-center gap-4">
          <a
            href="mailto:GenFlowGrid@gmail.com"
            className="font-mono text-[10px] tracking-[0.15em] text-bismuth hover:text-kinetic transition-colors duration-300 uppercase">

            GenFlowGrid@gmail.com
          </a>
          <span className="text-bismuth/30">|</span>
          <a
            href="https://instagram.com/genflowgrid"
            target="_blank"
            rel="noopener noreferrer"
            className="font-mono text-[10px] tracking-[0.15em] text-bismuth hover:text-kinetic transition-colors duration-300 uppercase">

            @genflowgrid
          </a>
        </div>
        <span className="font-mono text-[10px] tracking-[0.15em] text-bismuth uppercase">
          Pretoria, South Africa
        </span>
      </div>
    </footer>);

}
