import React from "react";
import { motion } from "framer-motion";

export default function HeroSection({ heroImage }) {
  return (
    <section id="home" className="relative min-h-screen flex flex-col overflow-hidden">
      {/* Background visual */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Abstract architectural visual with light refracting through glass and metal surfaces"
          className="w-full h-full object-cover opacity-35" />

        <div className="absolute inset-0 bg-gradient-to-t from-void via-void/70 to-void/40" />
        <div
          className="absolute inset-0 opacity-[0.015]"
          style={{
            backgroundImage: `linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)`,
            backgroundSize: "64px 64px"
          }} />

      </div>

      {/* Top metadata bar */}
      <div className="relative z-10 flex items-start justify-between px-6 md:px-10 pt-28 md:pt-32">
        <motion.p
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="font-mono text-[10px] tracking-[0.2em] text-kinetic uppercase">

          ● Digital Architecture
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="font-mono text-[10px] tracking-[0.15em] text-bismuth uppercase text-right">

          <p>Web Design Studio</p>
          <p className="mt-1 text-bismuth/60">Est. 2026</p>
        </motion.div>
      </div>

      {/* Main content */}
      <div className="relative z-10 mt-auto px-6 md:px-10 pb-16 md:pb-20 max-w-4xl">
        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="font-heading text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold text-lithos tracking-tighter leading-[0.9]">

          ARCHITECTING
          <br />
          DIGITAL
          <br />
          <span className="text-kinetic">FLOW.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="mt-8 text-lg text-bismuth max-w-md leading-relaxed">

          We build clean, modern websites for businesses that demand presence — not just pages.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mt-10">

          <a
            href="#portal"
            className="inline-flex items-center gap-3 px-8 py-4 bg-kinetic text-void font-mono text-xs tracking-[0.15em] uppercase hover:bg-lithos transition-colors duration-500">

            Initiate Collaboration
            <span className="text-base">→</span>
          </a>
          <a
            href="#archive"
            className="font-mono text-xs tracking-[0.15em] text-bismuth hover:text-lithos transition-colors duration-300 uppercase border-b border-bismuth/20 hover:border-lithos pb-1">

            View Selected Work
          </a>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 1 }}
        className="absolute bottom-6 right-6 md:right-10 flex flex-col items-center gap-2">

        <span className="font-mono text-[9px] tracking-[0.2em] text-bismuth uppercase rotate-90 origin-center translate-x-3">
          Scroll
        </span>
        <div className="w-[1px] h-10 bg-white/10 relative overflow-hidden">
          <motion.div
            animate={{ y: ["-100%", "100%"] }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            className="w-full h-1/2 bg-kinetic" />

        </div>
      </motion.div>
    </section>);

}
