import React from "react";
import { motion } from "framer-motion";
import { Mail, Instagram } from "lucide-react";

export default function PortalSection() {
  return (
    <section id="portal" className="py-24 md:py-40 px-6 md:px-10">
      <div className="mb-16 md:mb-24">
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="font-mono text-[10px] tracking-[0.2em] text-kinetic uppercase mb-4"
        >
          ● Inquiry Portal
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold text-lithos tracking-tighter leading-[0.95] max-w-3xl"
        >
          READY TO BUILD
          <br />
          SOMETHING
          <br />
          <span className="text-kinetic">EXCEPTIONAL?</span>
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="mt-8 text-lg text-bismuth max-w-lg leading-relaxed"
        >
          Every project begins with a conversation. Reach out through your preferred channel and we'll get back to you same day.
        </motion.p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
        <motion.a
          href="mailto:GenFlowGrid@gmail.com"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="group block p-8 md:p-12 border border-white/[0.04] bg-white/[0.01] hover:bg-white/[0.03] hover:border-kinetic/20 transition-all duration-500"
        >
          <div className="flex items-start justify-between mb-12 md:mb-20">
            <span className="font-mono text-[10px] tracking-[0.2em] text-bismuth uppercase">
              Direct Channel
            </span>
            <Mail className="w-5 h-5 text-bismuth group-hover:text-kinetic transition-colors duration-500" />
          </div>
          <p className="font-heading text-3xl md:text-4xl font-bold text-lithos tracking-tight group-hover:text-kinetic transition-colors duration-500">
            EMAIL
          </p>
          <p className="font-mono text-xs text-bismuth mt-3 tracking-wide break-all">
            GenFlowGrid@gmail.com
          </p>
          <div className="mt-8 flex items-center gap-3">
            <span className="font-mono text-[10px] tracking-[0.15em] text-kinetic uppercase">
              Send Inquiry
            </span>
            <span className="text-kinetic group-hover:translate-x-2 transition-transform duration-500">→</span>
          </div>
        </motion.a>

        <motion.a
          href="https://instagram.com/genflowgrid"
          target="_blank"
          rel="noopener noreferrer"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1, duration: 0.6 }}
          className="group block p-8 md:p-12 border border-white/[0.04] bg-white/[0.01] hover:bg-white/[0.03] hover:border-kinetic/20 transition-all duration-500"
        >
          <div className="flex items-start justify-between mb-12 md:mb-20">
            <span className="font-mono text-[10px] tracking-[0.2em] text-bismuth uppercase">
              Social Protocol
            </span>
            <Instagram className="w-5 h-5 text-bismuth group-hover:text-kinetic transition-colors duration-500" />
          </div>
          <p className="font-heading text-3xl md:text-4xl font-bold text-lithos tracking-tight group-hover:text-kinetic transition-colors duration-500">
            INSTAGRAM
          </p>
          <p className="font-mono text-xs text-bismuth mt-3 tracking-wide">
            @genflowgrid — DM us
          </p>
          <div className="mt-8 flex items-center gap-3">
            <span className="font-mono text-[10px] tracking-[0.15em] text-kinetic uppercase">
              Open Profile
            </span>
            <span className="text-kinetic group-hover:translate-x-2 transition-transform duration-500">→</span>
          </div>
        </motion.a>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.3, duration: 0.6 }}
        className="mt-6 md:mt-8 p-6 md:p-8 bg-kinetic flex flex-col md:flex-row items-center justify-between gap-4"
      >
        <p className="font-heading text-xl md:text-2xl font-bold text-void tracking-tight text-center md:text-left">
          INITIATE COLLABORATION
        </p>
        <div className="flex items-center gap-6">
          <a
            href="mailto:GenFlowGrid@gmail.com"
            className="font-mono text-xs tracking-[0.12em] text-void/70 hover:text-void transition-colors duration-300 uppercase"
          >
            Email
          </a>
          <span className="text-void/30">|</span>
          <a
            href="https://instagram.com/genflowgrid"
            target="_blank"
            rel="noopener noreferrer"
            className="font-mono text-xs tracking-[0.12em] text-void/70 hover:text-void transition-colors duration-300 uppercase"
          >
            Instagram
          </a>
        </div>
      </motion.div>
    </section>
  );
}
