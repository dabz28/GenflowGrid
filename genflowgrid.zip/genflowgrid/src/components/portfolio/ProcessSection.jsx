import React from "react";
import { motion } from "framer-motion";

const steps = [
  {
    num: "01",
    name: "Message us",
    desc: "Tell us about your business and what you need. No forms, no calls — just a quick email or DM on Instagram.",
  },
  {
    num: "02",
    name: "We design",
    desc: "We put together a clean, professional site built specifically for your business and your customers.",
  },
  {
    num: "03",
    name: "You review",
    desc: "We send you a preview. You give us feedback. We refine until it looks exactly right.",
  },
  {
    num: "04",
    name: "Site goes live",
    desc: "Once you're happy, your site is published and ready for customers to find you online.",
  },
];

export default function ProcessSection() {
  return (
    <section id="process" className="py-24 md:py-40 px-6 md:px-10">
      <div className="flex items-start justify-between mb-16 md:mb-24">
        <div>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="font-mono text-[10px] tracking-[0.2em] text-kinetic uppercase mb-4"
          >
            ● Methodology
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold text-lithos tracking-tighter leading-[0.95]"
          >
            HOW WE
            <br />
            WORK
          </motion.h2>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-0 border border-white/[0.04]">
        {steps.map((step, i) => (
          <motion.div
            key={step.num}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1, duration: 0.6 }}
            className="group p-8 md:p-12 border border-white/[0.04] hover:bg-white/[0.02] transition-colors duration-500"
          >
            <div className="flex items-start justify-between mb-8">
              <span className="font-mono text-[10px] tracking-[0.2em] text-kinetic">
                {step.num}
              </span>
              <div className="w-2 h-2 rounded-full bg-white/10 group-hover:bg-kinetic transition-colors duration-500" />
            </div>
            <h3 className="font-heading text-2xl md:text-3xl font-bold text-lithos tracking-tight mb-4">
              {step.name}
            </h3>
            <p className="text-base text-bismuth leading-relaxed max-w-sm">
              {step.desc}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
