/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: ["./index.html", "./src/**/*.{ts,tsx,js,jsx}"],
  theme: {
    extend: {
      borderRadius: {
        lg: 'var(--radius)',
        md: 'calc(var(--radius) - 2px)',
        sm: 'calc(var(--radius) - 4px)'
      },
      colors: {
        background: 'hsl(var(--background))',
        foreground: 'hsl(var(--foreground))',
        void: '#080808',
        lithos: '#F2F2F2',
        bismuth: '#808080',
        kinetic: '#BCFF00',
        card: {
          DEFAULT: 'hsl(var(--card))',
          foreground: 'hsl(var(--card-foreground))'
        },
        border: 'hsl(var(--border))',
        input: 'hsl(var(--input))',
        ring: 'hsl(var(--ring))'
      },
      fontFamily: {
        heading: ['Syne', 'var(--font-heading)'],
        body: ['Inter', 'var(--font-body)'],
        display: ['Syne', 'var(--font-display)'],
        mono: ['JetBrains Mono', 'var(--font-mono)']
      }
    }
  },
  plugins: [require("tailwindcss-animate")],
}
