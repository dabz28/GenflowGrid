# GenFlowGrid — Portfolio Site

This is your portfolio site, migrated off Base44. It's a plain React + Vite +
Tailwind project — it'll run on any static host (Netlify, Vercel, Cloudflare
Pages, GitHub Pages, etc.) with zero platform lock-in.

## What changed from the Base44 version

- **Removed the login system entirely.** The old version required visitors to
  log in before seeing your homepage (Login, Register, ForgotPassword,
  ResetPassword pages, plus the auth context and Base44 SDK client). Since you
  want a public portfolio, none of that is needed — the site now just shows
  the homepage directly to everyone.
- **Removed the `@base44/sdk` and `@base44/vite-plugin` packages** and
  anything that talked to Base44's backend. Nothing in this project calls out
  to Base44 anymore.
- **All visual components are untouched** — Navbar, HeroSection,
  ArchiveSection, ServicesSection, ProcessSection, PortalSection, Footer,
  WorkCard, StoryViewer. Same design, same animations, same layout.

## About the images — action needed

Your hero background and the 3 project images (background + "live preview"
screenshot for each) were hosted on Base44's media servers
(`media.base44.com`), which I can't fetch from. I've dropped in placeholder
images in `public/assets/images/` labeled with the filename they need to
replace, just so the site isn't full of broken image icons.

**Replace these 7 files** in `public/assets/images/` with your real images
(keep the same filenames, or update the paths in `src/pages/Home.jsx`):

- `hero-bg.png` — homepage hero background
- `ironforge-bg.png` / `ironforge-live.png`
- `sakhumzi-bg.png` / `sakhumzi-live.png`
- `faderoom-bg.png` / `faderoom-live.png`

## Running locally

```
npm install
npm run dev
```

## Building for deployment

```
npm run build
```

This outputs a `dist/` folder — upload that folder to whichever host you're
moving to (Netlify, Vercel, etc.), or connect the host directly to your Git
repo and point the build command at `npm run build` with output directory
`dist`.
